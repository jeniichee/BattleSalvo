# Change Log

## Old PA03 to PA04 Files

- BattleSalvoController class changed to Controller interface and LocalController class
    - Changed to allow more abstraction
    - Controller interface has run method
    - LocalController class provides implementation for run and adds helper methods
- AutoPlayer and ManualPlayer classes changed to AbstractPlayer, AiPlayer, and ManualPlayer
    - Changed to follow the Liskov substitution principle and more abstraction
    - AbstractPlayer has now only contains Board field
    - ManualPayer has additional ViewInput field
    - AutoPlayer has additional previousShots field
    - Removed methods not in Player interface
- Board class changed to BoardState interface, Board interface, and BoardImpl class
    - Changed to allow more abstraction as well as allowing the controller and view to not access all the Board's
      methods
    - BoardState has the methods isGameOver, getCoord, and setCoord
    - Board has the methods getHeight, getWidth, getAliveShips, updateShips, getShipCoords, and setup
    - BoardImpl has fields height, width, grid, ships, and enemyHitShots
    - Biggest Change: the grid field holds the user's view of the opponent's board and the board now holds the list of
      user's ships
- BattleSalvoView changed to ViewInput interface, ViewOutput interface, and ConsoleView class
    - ViewInput deals with obtain input from the user
    - ViewOutput outputs deals with the output methods
    - ConsoleView is the implementation of ViewInput and ViewOutput
- Changes in enumerations
    - Added CoordState enumeration and Direction enumeration
    - Changed ShipType enumeration to only have the size of the ship


