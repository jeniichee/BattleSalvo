package cs3500.pa04.controller;

/**
 * Represents the Controller interface
 */
public interface Controller {
  /**
   * Run method meant to run the BattleSalvoGame
   */
  void run();
}
