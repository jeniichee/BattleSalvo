package cs3500.pa04.model.player;

/**
 * Represents the result of the GameResult
 */
public enum GameResult {
  WIN,
  LOSE,
  DRAW
}

