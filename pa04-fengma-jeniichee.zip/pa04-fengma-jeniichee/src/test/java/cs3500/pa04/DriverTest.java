package cs3500.pa04;

import org.junit.jupiter.api.Test;

/**
 * DriverTest
 */
class DriverTest {

  /**
   * Test main function
   */
  @Test
  public void testMain() {
    return;
  }
}